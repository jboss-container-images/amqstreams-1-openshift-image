# AMQ Streams Proxy Examples

In this directory you'll find examples that let you try out AMQ Streams Proxy.
At present, one use-case is ready, which is Record Encryption.  Additional use-cases will be introduced later.

* [Record Encryption](./record-encryption)

